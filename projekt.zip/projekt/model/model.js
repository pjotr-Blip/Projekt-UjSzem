const mysql = require("mysql2/promise")

//adatbázis kapcsolat létrehozása:
const kapcsolat = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "ujszem_projekt"
})

module.exports = {
        cikkekListaz: async () =>{
        const [sorok] = await kapcsolat.query(
            `select cim, LEFT(szoveg, 200) as Leiras from cikkek;`
        )
        return sorok
    }
}