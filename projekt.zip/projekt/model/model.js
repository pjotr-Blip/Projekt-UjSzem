const mysql = require("mysql2/promise")

//adatbázis kapcsolat létrehozása:
const kapcsolat = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "ujszem_projekt"
})

module.exports = {
        cikkekListaz: async () =>{
        const [sorok] = await kapcsolat.query(
            `select cim, LEFT(szoveg, 350) as Leiras, kep_utvonal from cikkek;`
        )
        return sorok
    }
}