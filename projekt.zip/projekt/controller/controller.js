const model = require("../model/model")

exports.cikkekListaz = async (req, res)=>{
    try  {
        const cikkek = await model.cikkekListaz()
        res.json(cikkek)
    } catch (h) {
        res.status(404).json({
            hiba: h.message
        })
    }
}