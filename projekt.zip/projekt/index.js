
const express = require("express")

const app = express()

const routes = require("./routes/routes")
const bodyParser = require("body-parser")


app.use('/api', routes)
//JSON kommunikáció
app.use(bodyParser.json())
//public mappa staikussá tétele
app.use(express.static('public'))



app.get('/', (req,res)=>{
    res.sendFile(__dirname + '/public/index.html')
})


app.listen(3000, (req,res)=>{
    console.log("A szerver fut: http://localhost:3000");
    
})