const kartyamezo = document.getElementById("slidy-kartya");

document.addEventListener("DOMContentLoaded", async () => {
    const adatok = await fetch("/api/cikkek");
    const cikkek = await adatok.json();


    cikkek.forEach(cikk =>{
        kartyamezo.innerHTML += `
            <div class="card">
                <h2 class="slider-container">${cikk.cim}</h2>
                <p class="slider-container">${cikk.Leiras}</p>
            </div>
        
        `
    })
})