const controller = require("../controller/controller")

//importálni kell az express, az útvonalak tárolása miatt
const express = require("express")
const router = express.Router()

router.get("/cikkek", controller.cikkekListaz)

module.exports = router