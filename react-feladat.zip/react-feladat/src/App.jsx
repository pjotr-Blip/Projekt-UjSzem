import React, { useState } from "react";
import './App.css'
import VarosUrlap from "./components/varosiurlap/varosiurlap";
import Elorejelzes from "./components/elorejelzes/elorejelzes";

export default function App() {
  const [idojarasInfo, setIdojarasInfo] = useState(null);

  function queryWeather(varos) {
    fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${varos.latitude}&longitude=${varos.longitude}&daily=weathercode,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,uv_index_max,uv_index_clear_sky_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,windspeed_10m_max,windgusts_10m_max,winddirection_10m_dominant,shortwave_radiation_sum,et0_fao_evapotranspiration&timezone=auto`
    )
      .then((x) => x.json())
      .then((response) => {
        setIdojarasInfo({
          varos,
          idojaras: response
        });
      });
  }

  function updateVaros(varos) {
    fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${varos}`)
      .then((x) => x.json())
      .then((response) => {
        if (
          Array.isArray(response.results) &&
          response.results.length > 0
        ) {
          queryWeather(response.results[0]);
        } else {
          alert("Hibás város");
        }
      });
  }

  return (
    <div className="App">
      <h1>Időjárás előrejelzés</h1>
      <VarosUrlap updateVaros={updateVaros} />
      <Elorejelzes idojarasInfo={idojarasInfo} />
    </div>
  );
}